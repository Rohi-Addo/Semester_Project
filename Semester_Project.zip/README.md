# Semester_Project
## Name: Rohi Kweku Addo
## Program: Bsc.Information Technology(B)
## Index Number:UEB3221522
Project Description
## Traffic Management System
  Traffic Management System will provide a program to automate the regulation of traffic lights. It will make use of 
  Standard C++ libraries to create a program that will automatically manage the traffic using traffic signals that  
  will change bassed on the logic defined in the program.
